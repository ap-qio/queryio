package BigQuery;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;

public class S3GetQuery {
	
		/*
	 	 * This program fetches a given BigQuery
		 * @param serverURL: URL of s3 server.
		 * @param token: authorization token.
		 * @param queryId: Id of the query to be retrieved
		 */
	public static void getBigQuery(String serverURL, String token, String queryId)
			throws Exception {
		URL url = null;
		HttpURLConnection httpCon = null;
		InputStream is = null;
		try {
			/* append "/" at end of serverURL */
			if (!serverURL.endsWith("/")) {
				serverURL = serverURL + "/";
			}
			url = new URL(serverURL + "bigquery");	//append "bigquery" to the serverURL and create a new URL object

			//Returns a URLConnection object that represents a connection to the remote object referred to by the URL.
			httpCon = (HttpURLConnection) url.openConnection();

			httpCon.setDoOutput(true);	// to use the URL connection for output
			httpCon.setRequestMethod("GET");	//GET request is used

			httpCon.setRequestProperty("authorization", token);	//provides authorization token for authentication
			httpCon.setRequestProperty("bigquery-id", queryId);	//provides id of the query to be retrieved
			
			httpCon.connect();	//Opens a communications link to the resource reference by the URL

			if (httpCon.getResponseCode() == HttpStatus.SC_OK) {	//check for OK response
				is = httpCon.getInputStream();
				// Process response here
				StringWriter writer = new StringWriter();                 
				IOUtils.copy(is, writer, "UTF-8");                 
				System.out.println(writer.toString()); 
			}
		} finally {
			try {
				if (is != null)
					is.close();	//close InputStream
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (httpCon != null) {
				httpCon.disconnect();	//close connection
			}
		}
	}
	
	public static String login(String serverURL, String username,
			String password) throws Exception {
		URL url = null;
		HttpURLConnection httpCon = null;
		String token = null;
		try {
			/* appending "/" at the end of serverURL */
			if (!serverURL.endsWith("/")) {
				serverURL = serverURL + "/";
			}
			url = new URL(serverURL); //create a new URL object

			//Returns a URLConnection object that represents a connection to the remote object referred to by the URL.
			httpCon = (HttpURLConnection) url.openConnection();			
			
			httpCon.setDoOutput(true);	// to use the URL connection for output
			httpCon.setRequestMethod("GET");	//GET request to be used

			httpCon.addRequestProperty("username", username);	//set username property of HttpURLConnection
			httpCon.addRequestProperty("password", password);	//set password property of HttpURLConnection

			httpCon.connect();	//Opens a communications link to the resource reference by the URL

			if (httpCon.getResponseCode() == HttpStatus.SC_OK) {
				token = httpCon.getHeaderField("authorization");	//get authorization token
				// Use this token in subsequent requests for the current
				// session.
			}
		} finally {	//close connection
			if (httpCon != null) {
				httpCon.disconnect();
			}
		}

		return token;
	}
	
	public static void main(String argv[])
	{
		try {
			String token;
			token= login("http://192.168.0.1:6678/queryio/","admin","admin");
			
			System.out.print("Reply Token: "+token);
			
			getBigQuery("http://192.168.0.1:6678/queryio/", token, "New Query 1");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
package DFSClientAPI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DFSConfigKeys;

public class FetchFile {
	/*
	 * This program reads a file from HDFS and saves it on the local file system.
	 */
	public static void main(String[] args) throws IOException{
		Configuration conf = new Configuration(true);	//Create a configuration object to define hdfs properties
		conf.set(DFSConfigKeys.FS_DEFAULT_NAME_KEY, "hdfs://192.168.0.16:9000"); // URL for your namenode
		conf.set(DFSConfigKeys.DFS_REPLICATION_KEY, "3"); // Replication count for files you write
		
		OutputStream os = null;
		InputStream is = null;
		try{
			//Initialize DFS FileSystem object with QueryIO configurations 
			FileSystem dfs = FileSystem.get(conf);	
			dfs.mkdirs(new Path("/queryio/demo/"));	//creates new directory if it doesn't exist
			
			is = dfs.open(new Path("/queryio/demo/file.txt"));	//InputStream to the object to be GET
			
			os = new FileOutputStream(new File("/Applications/QueryIO/a.txt"));	//OutputStream to a local filesystem file
			
			IOUtils.copy(is, os);	//copy bytes from InputStream to OutputStream : Fetch File Operation
		} finally {
			try{
				if(is!=null)
					is.close();	//close InputStream
			} catch(Exception e){
				e.printStackTrace();
			}
			try{
				if(os!=null)
					os.close();	//close OutputStream
			} catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}


package DFSClientAPI;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DFSConfigKeys;

public class GetDirectoryList {
	/*
	 * This program lists all the directories in a server non recursively.
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException{
		Configuration conf = new Configuration(true);	//Create a configuration object to define hdfs properties
		conf.set(DFSConfigKeys.FS_DEFAULT_NAME_KEY, "hdfs://192.168.0.16:9000"); // URL for your namenode
		conf.set(DFSConfigKeys.DFS_REPLICATION_KEY, "3"); // Replication count for files you write
		
		FileSystem dfs = FileSystem.get(conf);	//Returns the configured filesystem implementation.
		FileStatus[] statusList = dfs.listStatus(new Path("/"));
		for(int i=0; i<statusList.length; i++){
			if(statusList[i].isDir()){
				System.out.println(statusList[i].getPath().getName());
			}
		}
	}
}


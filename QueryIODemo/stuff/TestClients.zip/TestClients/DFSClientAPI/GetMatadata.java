package DFSClientAPI;


import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DFSConfigKeys;

public class GetMatadata {
	/*
	 * This program deletes the specified object/file from the HDFS.
	 */
	
	public static void main(String[] args) throws IOException, NoSuchAlgorithmException{
		Configuration conf = new Configuration(true);	//Create a configuration object to define hdfs properties
		conf.set(DFSConfigKeys.FS_DEFAULT_NAME_KEY, "hdfs://192.168.0.16:9000"); // URL for your namenode
		conf.set(DFSConfigKeys.DFS_REPLICATION_KEY, "3"); // Replication count for files you write
		
		Path filePath = new Path("/queryio/demo/file.txt");	//defines a dfs path to file1.txt

		FileSystem dfs = FileSystem.get(conf);	//Hadoop FileSystem object with configuration
		FileStatus fs = dfs.getFileStatus(filePath);	//HEAD Object operation: Return a file status object that represents the path.
		
		InputStream is = dfs.open(filePath);	//InputStream to the file1.txt
		MessageDigest md = MessageDigest.getInstance("MD5");	// Generates a MessageDigest object that implements the MD5 algorithm.
		try {
		  is = new DigestInputStream(is, md);	//stream that updates the associated message digest using the bits going through the stream
		  // read stream to EOF as normal...
		}
		finally {
		  is.close();	//close InputStream
		}
		byte[] digest = md.digest();	//Completes the hash computation by performing final operations
		
		
		System.out.println("Length : " + fs.getLen());
		System.out.println("Modification Time : " + new Timestamp(fs.getModificationTime()));
		System.out.println("Checksum : " + new String(digest));		
	}	
}

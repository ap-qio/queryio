package DFSClientAPI;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DFSConfigKeys;

public class CreateFile {
	/*
	 * This program reads a file from the local file system and saves it on HDFS.
	 */
	public static void main(String[] args) throws IOException{
		Configuration conf = new Configuration(true);	//Create a configuration object to define hdfs properties
		conf.set(DFSConfigKeys.FS_DEFAULT_NAME_KEY, "hdfs://192.168.0.16:9000"); // URL for your namenode
		conf.set(DFSConfigKeys.DFS_REPLICATION_KEY, "3"); // Replication count for files you write
		
		OutputStream os = null;
		InputStream is = null;
		try{
			// First initialize DFS FileSystem object  
			FileSystem dfs = FileSystem.get(conf);	//Hadoop FileSystem object with QueryIO configuration
			dfs.mkdirs(new Path("/queryio/demo/"));	//created a new directory "demo"
			
			os = dfs.create(new Path("/queryio/demo/file.txt"));	//return a OutputStream at indicated path
			
			is = new FileInputStream(new File("/Applications/QueryIO/license.html"));	//InputStream from a local filesystem file
			
			IOUtils.copy(is, os);	//copy bytes from InputStream to OutputStream : create Object Operation
		} finally {
			try{
				if(is!=null)
					is.close();	//close InputStream
			} catch(Exception e){
				e.printStackTrace();
			}
			try{
				if(os!=null)
					os.close();	//close OutputStream
			} catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}	



package DFSClientAPI;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DFSConfigKeys;

public class DeleteDirectory {
	/*
	 * This program deletes the specified directory from HDFS.
	 */
	public static void main(String[] args) throws IOException{
		Configuration conf = new Configuration(true);	//Create a configuration object to define hdfs properties
		conf.set(DFSConfigKeys.FS_DEFAULT_NAME_KEY, "hdfs://192.168.0.16:9000"); // URL for your namenode
		conf.set(DFSConfigKeys.DFS_REPLICATION_KEY, "3"); // Replication count for files you write
		
		FileSystem dfs = FileSystem.get(conf);	//Initialize DFS FileSystem object with QueryIO configurations 
		dfs.delete(new Path("/queryio/"), true); // Deletes files in the folder recursively
	}
}


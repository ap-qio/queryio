package DFSClientAPI;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DFSConfigKeys;

public class DeleteFile {
	/*
	 * This program deletes the specified file from the HDFS.
	 */
	public static void main(String[] args) throws IOException{
		Configuration conf = new Configuration(true);	//Create a configuration object to define hdfs properties
		conf.set(DFSConfigKeys.FS_DEFAULT_NAME_KEY, "hdfs://192.168.0.16:9000"); // URL for your namenode
		//conf.set(DFSConfigKeys.DFS_REPLICATION_KEY, "3"); // Replication count for files you write
		
		//Initialize DFS FileSystem object with QueryIO configurations 
		FileSystem dfs = FileSystem.get(conf);
		dfs.delete(new Path("/queryio/demo/file.txt"), true); // Deleting just the file
	}
}



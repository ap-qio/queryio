package com.os3.server.hive;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.codehaus.jettison.json.JSONArray;
import org.json.simple.JSONObject;

import com.queryio.common.util.AppLogger;

public class S3HiveDataDefinition {

	/*
	 * This program fetches a given BigQuery
	 * 
	 * @param serverURL: URL of s3 server.
	 * 
	 * @param token: authorization token.
	 * 
	 * @param queryJSON: JSON of the query to be executed
	 */
	public static void addHiveDefinition(String serverURL, String token, JSONObject jsonObject) throws Exception {

		URL url = null;
		HttpURLConnection httpCon = null;
		InputStream is = null;
		try {
			/* append "/" at end of serverURL */
			if (!serverURL.endsWith("/")) {
				serverURL = serverURL + "/";
			}
			System.out.println("serverURL" + serverURL);
			url = new URL(serverURL + "hive"); // append "hive" to the
												// serverURL and create a
												// new URL object

			// Returns a URLConnection object that represents a connection to
			// the remote object referred to by the URL.
			httpCon = (HttpURLConnection) url.openConnection();
			System.err.println(httpCon.getClass());

			httpCon.setDoOutput(true); // to use the URL connection for output
			httpCon.setRequestMethod("POST"); // POST request is used

			httpCon.setRequestProperty("authorization", token); // provides
																// authorization
																// token for
																// authentication
//			httpCon.setRequestProperty("hivejsonargs", json);
//			httpCon.setRequestProperty("startindex", "5");
//			httpCon.setRequestProperty("maxresults", "7");
//			httpCon.setRequestProperty("timeoutms", "300");
			httpCon.setRequestProperty("Content-Type","application/json");  
			OutputStream os = httpCon.getOutputStream();
			os.write(jsonObject.toJSONString().getBytes());
			os.close();
			httpCon.connect(); // Opens a communications link to the resource
								// referenced by the URL
			System.out.println(httpCon.getRequestProperty("hivejsonargs"));
			System.out.println(httpCon.getResponseCode());

			// IOUtils.copy(is, writer, "UTF-8");
			if (httpCon.getResponseCode() == HttpStatus.SC_OK) { // check for OK
																	// response
				is = httpCon.getInputStream();
				// Process response here
				StringWriter writer = new StringWriter();
				IOUtils.copy(is, writer, "UTF-8");
//				System.out.println("writer" + writer.toString());
			}
		} finally {
			try {
				if (is != null)
					is.close(); // close InputStream
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (httpCon != null) {
				httpCon.disconnect(); // close connection
			}
		}
	}

	

	public static String login(String serverURL, String username, String password) throws Exception {
		URL url = null;
		HttpURLConnection httpCon = null;
		String token = null;
		try {
			/* appending "/" at the end of serverURL */
			if (!serverURL.endsWith("/")) {
				serverURL = serverURL + "/";
			}
			url = new URL(serverURL); // create a new URL object

			// Returns a URLConnection object that represents a connection to
			// the remote object referred to by the URL.
			httpCon = (HttpURLConnection) url.openConnection();

			httpCon.setDoOutput(true); // to use the URL connection for output
			httpCon.setRequestMethod("GET"); // GET request to be used

			httpCon.addRequestProperty("username", username); // set username
																// property of
																// HttpURLConnection
			httpCon.addRequestProperty("password", password); // set password
																// property of
																// HttpURLConnection

			httpCon.connect(); // Opens a communications link to the resource
								// reference by the URL

			if (httpCon.getResponseCode() == HttpStatus.SC_OK) {
				token = httpCon.getHeaderField("authorization"); // get
																	// authorization
																	// token
				// Use this token in subsequent requests for the current
				// session.
			}
		} finally { // close connection
			if (httpCon != null) {
				httpCon.disconnect();
			}
		}

		return token;
	}

	@SuppressWarnings("unchecked")
	public static void main(String argv[]) {
		java.util.logging.Logger.getLogger("org.apache.http.wire").setLevel(java.util.logging.Level.FINEST);
		java.util.logging.Logger.getLogger("org.apache.http.headers").setLevel(java.util.logging.Level.FINEST);

		System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
		System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
		System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "debug");
		System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "debug");
		System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "debug");
		try {
			String token;
			token = login("http://192.168.1.3:5668/queryio/", "admin", "admin");
			System.out.println("Reply Token: " + token);
//			String json = "{\"fileType\":\"CSV\",\"adHocId\":\"Hive5\",\"nameNodeId\":\"NameNode1\",\"rmId\":\"ResourceManager1\",
//			\"sourcePath\":\"/Data/csv\",\"parseRecursive\":true,\"adHocTableName\":\"HiveCSVTable5\",
//			\"fileName\":\"C:\\fakepath\\MachineLogs_1364454240895.csv\",
//			\"filePathPattern\":\".*\\.csv\",
//			\"fields\":\"[{\"colName\":\"FILEPATH\",\"colType\":\"STRING(1280)\",\"colIndex\":0},
//			{\"colName\":\"IP\",\"colType\":\"STRING(255)\",\"colIndex\":1},
//			{\"colName\":\"CPU\",\"colType\":\"INTEGER\",\"colIndex\":2},
//			{\"colName\":\"RAM\",\"colType\":\"INTEGER\",\"colIndex\":3},
//			{\"colName\":\"DISKREAD\",\"colType\":\"INTEGER\",\"colIndex\":4},
//			{\"colName\":\"DISKWRITE\",\"colType\":\"INTEGER\",\"colIndex\":5},
//			{\"colName\":\"NETREAD\",\"colType\":\"INTEGER\",\"colIndex\":6},
//			{\"colName\":\"NETWRITE\",\"colType\":\"INTEGER\",\"colIndex\":7}]\",
//			\"delimiter\":\",\",\"valueSeparator\":\"\",\"isFirstRowHeader\":true,
//			\"pattern\":\"%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-agent}i\",
//			\"encoding\":\"UTF-8\",\"isSkipAllRecordsString\":null}";
			
//			{"adHocId":"Hive1","nameNodeId":"NameNode1","rmId":"ResourceManager1","sourcePath":"/Data/apachelog",
//				"parseRecursive":true,"adHocTableName":"HiveApacheLogTable1","fileName":"C:\\fakepath\\ApacheAccessLogs_1364897930501.accesslog",
//				"filePathPattern":".*\\.accesslog",
//				"fields":"[{\"colName\":\"FILEPATH\",\"colType\":\"STRING(1280)\",\"colIndex\":0},
//				{\"colName\":\"IP\",\"colType\":\"STRING(255)\",\"colIndex\":1},
//				{\"colName\":\"HYPHEN\",\"colType\":\"STRING(255)\",\"colIndex\":2},
//				{\"colName\":\"USER_NAME\",\"colType\":\"STRING(255)\",\"colIndex\":3},
//				{\"colName\":\"TIME_DATE\",\"colType\":\"STRING(255)\",\"colIndex\":4},
//				{\"colName\":\"REQUESTED_LINE\",\"colType\":\"STRING(255)\",\"colIndex\":5},
//				{\"colName\":\"STATUS_CODE\",\"colType\":\"INTEGER\",\"colIndex\":6},
//				{\"colName\":\"OBJECT_SIZE\",\"colType\":\"INTEGER\",\"colIndex\":7},
//				{\"colName\":\"REFERRER\",\"colType\":\"STRING(512)\",\"colIndex\":8},
//				{\"colName\":\"USER_AGENT\",\"colType\":\"STRING(512)\",\"colIndex\":9}]",
////				"pattern":"%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-agent}i\"","encoding":"UTF-8"}
			
			// IISLOG JSON
//			{"adHocId":"Hive1","nameNodeId":"NameNode1","rmId":"ResourceManager1",
//				"sourcePath":"/Data/iislog","parseRecursive":true,"adHocTableName":"HiveIISLOGTable1",
//				"fileName":"C:\\fakepath\\in20130216.iislog","filePathPattern":".*\\.iislog",
//				"fields":"[{\"colName\":\"FILEPATH\",\"colType\":\"STRING(1280)\",\"colIndex\":0},
//				{\"colName\":\"CLIENT_IP\",\"colType\":\"STRING(255)\",\"colIndex\":1},
//				{\"colName\":\"USERNAME\",\"colType\":\"STRING(255)\",\"colIndex\":2},
//				{\"colName\":\"LOG_DATE\",\"colType\":\"STRING(255)\",\"colIndex\":3},
//				{\"colName\":\"LOG_TIME\",\"colType\":\"STRING(255)\",\"colIndex\":4},
//				{\"colName\":\"SERVICEINSTANCE\",\"colType\":\"STRING(255)\",\"colIndex\":5},
//				{\"colName\":\"SERVERNAME\",\"colType\":\"STRING(255)\",\"colIndex\":6},
//				{\"colName\":\"SERVER_IP\",\"colType\":\"STRING(255)\",\"colIndex\":7},
//				{\"colName\":\"TIMETAKEN\",\"colType\":\"INTEGER\",\"colIndex\":8},
//				{\"colName\":\"CLIENT_BYTESSENT\",\"colType\":\"INTEGER\",\"colIndex\":9},
//				{\"colName\":\"SERVER_BYTESSENT\",\"colType\":\"INTEGER\",\"colIndex\":10},
//				{\"colName\":\"SERVICE_STATUSCODE\",\"colType\":\"INTEGER\",\"colIndex\":11},
//				{\"colName\":\"WINDOWS_STATUSCODE\",\"colType\":\"INTEGER\",\"colIndex\":12},
//				{\"colName\":\"REQUESTTYPE\",\"colType\":\"STRING(255)\",\"colIndex\":13},
//				{\"colName\":\"TARGETOFOPER\",\"colType\":\"STRING(255)\",\"colIndex\":14},
//				{\"colName\":\"LOG_PARAMETERS\",\"colType\":\"STRING(255)\",\"colIndex\":15}]",
//				"delimiter":",","isFirstRowHeader":true,"encoding":"UTF-8"}
			
			JSONArray fields = new JSONArray();
			JSONObject field1 = new JSONObject();
			field1.put("colName", "FILEPATH");
			field1.put("colType", "STRING(1280)");
			field1.put("colIndex", "0");
			fields.put(field1);
			JSONObject field10 = new JSONObject();
			field10.put("colName", "IP");
			field10.put("colType", "STRING(255)");
			field10.put("colIndex", "2");
			fields.put(field10);
			JSONObject field9 = new JSONObject();
			field9.put("colName", "RAM");
			field9.put("colType", "STRING(255)");
			field9.put("colIndex", "1");
			fields.put(field9);
			JSONObject field8 = new JSONObject();
			field8.put("colName", "CPU");
			field8.put("colType", "STRING(255)");
			field8.put("colIndex", "3");
			fields.put(field8);
			JSONObject field7 = new JSONObject();
			field7.put("colName", "DISKREAD");
			field7.put("colType", "STRING(255)");
			field7.put("colIndex", "4");
			fields.put(field7);
			JSONObject field6 = new JSONObject();
			field6.put("colName", "DISKWRITE");
			field6.put("colType", "STRING(255)");
			field6.put("colIndex", "5");
			fields.put(field6);
			JSONObject field5 = new JSONObject();
			field5.put("colName", "NETREAD");
			field5.put("colType", "STRING(255)");
			field5.put("colIndex", "6");
			fields.put(field5);
			JSONObject field4 = new JSONObject();
			field4.put("colName", "NETWRITE");
			field4.put("colType", "STRING(255)");
			field4.put("colIndex", "7");
			fields.put(field4);
//			JSONObject field3 = new JSONObject();
//			field3.put("colName", "TIMETAKEN");
//			field3.put("colType", "INTEGER");
//			field3.put("colIndex", "8");
//			fields.put(field3);
//			JSONObject field11 = new JSONObject();
//			field11.put("colName", "CLIENT_BYTESSENT");
//			field11.put("colType", "INTEGER");
//			field11.put("colIndex", "9");
//			fields.put(field11);
//			JSONObject field12 = new JSONObject();
//			field12.put("colName", "SERVER_BYTESSENT");
//			field12.put("colType", "INTEGER");
//			field12.put("colIndex", "10");
//			fields.put(field12);
//			JSONObject field13 = new JSONObject();
//			field13.put("colName", "SERVICE_STATUSCODE");
//			field13.put("colType", "INTEGER");
//			field13.put("colIndex", "11");
//			fields.put(field13);
//			JSONObject field2 = new JSONObject();
//			field2.put("colName", "WINDOWS_STATUSCODE");
//			field2.put("colType", "INTEGER");
//			field2.put("colIndex", "12");
//			fields.put(field2);
//			JSONObject field14 = new JSONObject();
//			field14.put("colName", "REQUESTTYPE");
//			field14.put("colType", "STRING(255)");
//			field14.put("colIndex", "13");
//			fields.put(field14);
//			JSONObject field15 = new JSONObject();
//			field15.put("colName", "TARGETOFOPER");
//			field15.put("colType", "INTEGER");
//			field15.put("colIndex", "14");
//			fields.put(field15);
//			JSONObject field16 = new JSONObject();
//			field16.put("colName", "LOG_PARAMETERS");
//			field16.put("colType", "STRING(255)");
//			field16.put("colIndex", "15");
//			fields.put(field16);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("fileType", "XML");
			jsonObject.put("adHocId", "Hive8");
			jsonObject.put("nameNodeId", "NameNode1");
			jsonObject.put("rmId", "ResourceManager1");
			jsonObject.put("sourcePath", "/Data/xml");
			jsonObject.put("parseRecursive", true);
			jsonObject.put("adHocTableName", "HiveXMLTable8");
			jsonObject.put("fileName", null);
			jsonObject.put("filePathPattern", ".*\\.xml");
			jsonObject.put("pattern", "%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-agent}i\"");
			jsonObject.put("fields", fields);
			jsonObject.put("delimiter", "");
			jsonObject.put("valueSeparator", "");
			jsonObject.put("nodeName" ,"LogDetails");
			jsonObject.put("isFirstRowHeader", true);
			jsonObject.put("pattern", "%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-agent}i");
			jsonObject.put("encoding", "UTF-8");
			jsonObject.put("isSkipAllRecordsString", null);

			addHiveDefinition("http://192.168.1.3:5668/queryio/", token, jsonObject); // (server
																				// URL,
																				// token,
																				// json)

		} catch (Exception e) {
			AppLogger.getLogger().error(e.getMessage(),e);
//			e.printStackTrace();
		}
	}
}
